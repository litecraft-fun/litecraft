<?PHP

define ("DBHOST", "144.76.36.221");

define ("DBNAME", "bd_site");

define ("DBUSER", "bd_site");

define ("DBPASS", "");

define ("PREFIX", "dle");

define ("USERPREFIX", "dle");

define ("COLLATE", "utf8mb4");

define('SECURE_AUTH_KEY', 'H/Ec[CPK:TR[.ra-v}&[;L3,R?gGI{c}nX``UU.K>sj:)}|:)1-82IM~8u+cRBkA');

$db = new db;

?>