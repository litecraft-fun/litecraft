<?PHP 

//Videoplayers Configurations

$video_config = array (

'width' => "600",

'audio_width' => "600",

'preload' => "1",

'theme' => "light",

);

?>