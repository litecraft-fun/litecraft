$('#money_tab').css('display', 'none');
$('#econs_tab').css('display', 'none');
$('#cases_tab').css('display', 'none');
$('#vote_tab').css('display', 'none');
$('.tab').css('width', '355px');
