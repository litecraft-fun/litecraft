<div class="function_block" style="width: 100%;">
        <div class="graphics"></div>
        <h3 class="title">
            Что вы получите, проголосовав в четырёх рейтингах?
        </h3>
        <div class="body">
            <div class="gift">
                <b>30000</b>
                $
            </div>
            <div class="gift">
                <b>4</b>
                кейса
            </div>
            <div class="gift" style="padding-top: 12px;">
                <b>4</b>
                очка в топе голосующих
            </div>
        </div>
    </div>