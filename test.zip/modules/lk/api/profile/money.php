<?php
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/lk/api/mysql.php');
echo $money;