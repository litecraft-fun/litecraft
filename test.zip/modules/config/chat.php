<?php
//1 - ITEM, 2 - ECON, 3 - MONEY
$chat = array( //кейсы
 "colors" => array (
        array(
           "title" => "Тёмно-синий", 
		   "hex" => '#0000AA',
		   "mc" => '&1'
        ),	
		array(
           "title" => "Тёмно-зелёный", 
		   "hex" => '#00AA00',
		   "mc" => '&2'
        ),
		array(
           "title" => "Тёмно-сине-зелёный", 
		   "hex" => '#00AAAA',
		   "mc" => '&3'
        ),
		array(
           "title" => "Тёмно-красный", 
		   "hex" => '#AA0000',
		   "mc" => '&4'
        ),
		array(
           "title" => "Тёмно-фиолетовый", 
		   "hex" => '#AA00AA',
		   "mc" => '&5'
        ),
		array(
           "title" => "Золотой", 
		   "hex" => '#FFAA00',
		   "mc" => '&6'
        ),
		array(
           "title" => "Серый", 
		   "hex" => '#AAAAAA',
		   "mc" => '&7'
        ),
		array(
           "title" => "Тёмно-серый", 
		   "hex" => '#555555',
		   "mc" => '&8'
        ),
		array(
           "title" => "Голубой", 
		   "hex" => '#5555FF',
		   "mc" => '&9'
        ),
		array(
           "title" => "Зелёный", 
		   "hex" => '#55FF55',
		   "mc" => '&a'
        ),
		array(
           "title" => "Сине-зелёный", 
		   "hex" => '#55FFFF',
		   "mc" => '&b'
        ),
		array(
           "title" => "Красный", 
		   "hex" => '#FF5555',
		   "mc" => '&c'
        ),
		array(
           "title" => "Светло-фиолетовый", 
		   "hex" => '#FF55FF',
		   "mc" => '&d'
        ),
		array(
           "title" => "Жёлтый", 
		   "hex" => '#FFFF55',
		   "mc" => '&e'
        ),
		array(
           "title" => "Белый", 
		   "hex" => '#FFFFFF',
		   "mc" => '&f'
        )
    )
);
