<?php
$payment = array (
    "merchant_id" => '217406',
    "secret_word" => 'pnf3a2gh'
);