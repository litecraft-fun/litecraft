<?php
//Protect
//require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/ddos/scripts.php');
//Imports
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/config/general.php');
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/config/servers.php');
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/config/donate.php');
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/config/cases.php');
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/config/chat.php');
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/config/history.php');
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/config/shop.php');
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/config/payment.php');
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/config/team.php');
require_once ($_SERVER['DOCUMENT_ROOT']. '/modules/config/ref.php');