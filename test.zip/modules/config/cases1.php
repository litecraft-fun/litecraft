<?php
//1 - ITEM, 2 - ECON, 3 - MONEY
$cases = array( //кейсы
	"DivineRPG" => array (
		array(
		"title" => "Шерсть",
		"type" => 1,
		"img" => 1,
		"amount" => 16,
		"id" => 'whitewool'
		)
		
    ),
		
	"GregTech" => array (
        array(
           "title" => "Камень", 
		   "type" => 1,
		   "img" => 1,
		   "amount" => 64,
           "id" => 1
        )
        
     ),  
    
	"Hitech" => array (
        array(
           "title" => "Камень", 
		   "type" => 1,
		   "img" => 1,
		   "amount" => 64,
           "id" => 1
        )
        
    ),
	"Magic" => array (
        array(
           "title" => "Камень", 
		   "type" => 1,
		   "img" => 1,
		   "amount" => 64,
           "id" => 1
        )
        
    ),
    "TechoMagicRPG" => array (
        array(
           "title" => "Камень", 
		   "type" => 1,
		   "img" => 1,
		   "amount" => 64,
           "id" => 1
        )
	),
	
);
