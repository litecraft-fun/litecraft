<?php
//by FlipFlare
$gifts = array( 
    "referals" => array (
	    "new_user" => array ( //Тот кто ввёл реферал
            "money" => 30, //Монеты
		    "econs" => 0, //$
			"cases" => 0 //Кейсы
		),
		"referal" => array ( //Тот кто дал реферал
			"money" => 15, 
		    "econs" => 0,
			"cases" => 0
		)
	)
);
