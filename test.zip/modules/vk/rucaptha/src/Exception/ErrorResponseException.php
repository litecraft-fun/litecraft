<?php
/**
 * @author Dmitry Gladyshev <deel@email.ru>
 */

namespace Rucaptcha\Exception;

class ErrorResponseException extends RuntimeException
{
}
