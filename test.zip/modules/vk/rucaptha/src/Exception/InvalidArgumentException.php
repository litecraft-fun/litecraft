<?php
/**
 * @author Dmitry Gladyshev <deel@email.ru>
 */

namespace Rucaptcha\Exception;

class InvalidArgumentException extends Exception
{
}
